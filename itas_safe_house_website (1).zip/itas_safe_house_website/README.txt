ITAS SAFE HOUSE WEBSITE
=======================

Files:
- index.html: complete responsive static website
- assets/: category preview images rendered from the supplied brochure and the brochure PDF

Preview:
Open index.html in a browser.

Free static hosting:
1. Create a GitHub account and a new public repository.
2. Upload index.html and the entire assets folder (keep the folder structure).
3. In repository Settings > Pages, choose Deploy from a branch, select main and / (root), then Save.
4. GitHub Pages will provide a public website URL.

WhatsApp:
The site links to +91 88669 45494. Update the number in index.html if needed.

Notes:
- This is a static website; no paid hosting or backend is required.
- Hosting providers may change their free-plan terms, so lifetime availability cannot be guaranteed.
- Product category names and examples are based on the supplied ITAS Safe House brochure.
